We use java to inplement the project.
Here we included in the package:
******************************************	
	Phase2.jar
	Phase2.java
	Block.java
	Loop.java
	Makefile
	README.txt
	GROUP.txt
*******************************************

There are two ways to run our program

1. use command " java -jar Phase2.jar *.mil"

2. use command 
	" make "
	" java Phase2 *.mil"

Our Project achieved print output of programs,count blocks numbers count edges numbers and count loops numbers.

If you have any question about this project, please contact us, thank you.