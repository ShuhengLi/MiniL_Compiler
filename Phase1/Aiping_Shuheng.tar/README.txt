We use java to inplement the project.
Here we include in the package:
******************************************	
	Phase1.jar
	Phase.java
	Makefile
	README.txt
	GROUP.txt
*******************************************

There are two ways to run our program

1. use command " java -jar Phase1.jar *.mil"

2. use command 
	" make "
	" java Phase1 *.mil"

If you have any question about this project, please contact us, thank you.